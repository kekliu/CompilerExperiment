#!/bin/sh
java -jar calculator.jar $*
