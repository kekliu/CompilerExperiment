/**
 * Operator Precedence Analysis for Operator Precedence Grammar (OPG) 
 * @author w-angler
 *
 */
package com.w_angler.calculator.frontend.opg;