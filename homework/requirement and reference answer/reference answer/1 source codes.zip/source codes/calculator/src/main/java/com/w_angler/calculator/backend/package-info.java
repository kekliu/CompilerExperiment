/**
 * A compiler backend for this calculator (strictly speaking, it's not a real backend)
 * @author w-angler
 *
 */
package com.w_angler.calculator.backend;