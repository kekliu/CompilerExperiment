/**
 * leaf node in abstact syntax tree
 * @author w-angler
 *
 */
package com.w_angler.calculator.backend.ast.leaf;