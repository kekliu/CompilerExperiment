/**
 * A compiler frontend
 * @author w-angler
 *
 */
package com.w_angler.calculator.frontend;