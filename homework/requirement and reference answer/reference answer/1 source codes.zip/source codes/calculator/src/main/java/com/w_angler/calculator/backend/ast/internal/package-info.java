/**
 * internal nodes in abstract syntax tree
 * @author w-angler
 *
 */
package com.w_angler.calculator.backend.ast.internal;