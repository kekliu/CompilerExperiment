/**
 * A stack-based virtual machine
 * @author w-angler
 *
 */
package com.w_angler.calculator.backend.stack_base;