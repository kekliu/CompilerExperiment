/**
 * exceptions
 * @author w-angler
 *
 */
package com.w_angler.calculator.exception;