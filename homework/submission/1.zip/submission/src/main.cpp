#include <iostream>
#include <list>
#include "scanner.hpp"
#include "parser.hpp"
#include "memoryleakcheck.hpp"
#include <fstream>

using namespace std;
using namespace cmplr;


SymbolTable symbol_table;

void printUsage()
{
	cout << "Usage: Calculator[.exe] filename" << endl;
}

int main(int argc, char* argv[])
{
	EnableMemLeakCheck();
	symbol_table.addOrUpdate("PI", TokenStruct(TOK_CONST_REAL, 3.14159265));
	symbol_table.addOrUpdate("E", TokenStruct(TOK_CONST_REAL, 2.718281828));
	//_CrtSetBreakAlloc(172);

	ifstream infile;

	while (true)
	{
		if (argc == 2)
		{
			infile = ifstream(argv[1]);
			if (!infile)
				cerr << "open file " << string(argv[1]) << " error" << endl;
			else
				break;
		}
		else if (argc == 1)
		{
			printUsage();
			break;
		}
		else
		{
			cout << "too much options!!" << endl;
			printUsage();
			break;
		}
	}

	string lineStr;
	list<TokenStruct> TokenList;
	list<ErrorMsg> ErrorList;

	int line_count = 1;

	while (getline(infile, lineStr))
	{
		try
		{
			//cout << "source code: " << string(lineStr.c_str()) << endl;

			TokenList.clear();

			scanner scnnr = scanner(TokenList, ErrorList, line_count);
			scnnr.exec(lineStr.c_str());

			if(TokenList.empty()) continue;

			parser prsr = parser(TokenList, ErrorList, symbol_table, line_count);
			prsr.exec();

		}
		catch (exception e)
		{
			cout << e.what() << endl;
		}
	}

	return 0;
}


