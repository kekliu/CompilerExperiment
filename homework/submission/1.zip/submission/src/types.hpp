#ifndef COMPLILER_TYPES_HPP
#define COMPLILER_TYPES_HPP

#include <ostream>
#include <string>
#include <exception>
#include <list>
#include <functional>


// a calculator demo with compiler technique
namespace cmplr
{

	enum TokenType
	{
		// keywords

		// operaters
		TOK_OP_ASSIGN, TOK_OP_PLUS, TOK_OP_MINUS, TOK_OP_TIMES, TOK_OP_DIVIDE,
		// seperators
		TOK_PUNC_LPAREN, TOK_PUNC_RPAREN, TOK_PUNC_SEMI,
		// constants
		TOK_CONST_INT, TOK_CONST_REAL,

		TOK_ID, TOK_FUNC, TOK_ERROR, TOK_EOF,
	};

	const char *TokenNames[] =
	{
		//"print",
		"=","+","-","*","/",
		"(",")",";",
		"const_int","const_real",
		"id", "function", "error", "eof",
	};

	struct ErrorMsg
	{
		int rows;
		int cols;
		char message[30];
	};

	struct TokenStruct
	{
		int row, col;

		TokenType type;
		union
		{
			int i_value;
			double d_value;
			char id_value[15];
		};

		TokenStruct() {}
		TokenStruct(TokenType t) { type = t; }
		TokenStruct(TokenType t, double value)
		{
			type = t;
			if (t == TOK_CONST_INT)
				i_value = int(value);
			else if (t == TOK_CONST_REAL)
				d_value = value;
			else
				throw std::exception("not implement");
		}
	};

	typedef struct AstNode
	{
		TokenStruct tok;
		struct AstNode *left, *right;
	} AstNode;

	std::ostream &operator<<(std::ostream &out, TokenStruct &A)
	{
		switch (A.type)
		{
		case TOK_OP_ASSIGN:case TOK_OP_PLUS:case TOK_OP_MINUS:case TOK_OP_TIMES:
		case TOK_OP_DIVIDE:case TOK_PUNC_LPAREN:case TOK_PUNC_RPAREN:case TOK_PUNC_SEMI:
			out << std::string(TokenNames[A.type]);
			break;
		case TOK_CONST_INT:
			out << "<" << TokenNames[A.type] << ", " << A.i_value << ">";
			break;
		case TOK_CONST_REAL:
			out << "<" << TokenNames[A.type] << ", " << A.d_value << ">";
			break;
		case TOK_ID:case TOK_FUNC:
			out << "<" << TokenNames[A.type] << ", " << std::string(A.id_value) << ">";
			break;
		default:
			out << "unrecognized token";
			break;
		}
		return out;
	}


	std::ostream &operator<<(std::ostream &out, std::list<TokenStruct> &l)
	{
		for (std::list<TokenStruct>::iterator it = l.begin(); it != l.end(); ++it)
			out << *it << std::endl;
		return out;
	}

}

#endif
