#ifndef DEMO_COMPLILER_SCANNER_HPP
#define DEMO_COMPLILER_SCANNER_HPP


#include <list>
#include <string.h>
#include "types.hpp"
#include "symbol.hpp"

using namespace std;


namespace cmplr
{

	class scanner
	{

		// public variables
	private:
		// 必须使用引用类型
		list<TokenStruct> &TokenList;
		list<ErrorMsg> &ErrorList;
		int &row;

		// constructor
	public:
		scanner(list<TokenStruct> &tlst, list<ErrorMsg> &elst, int &r) :
			TokenList(tlst), ErrorList(elst), row(r) { }

	public:
		TokenType get_one_token(char *&p, char *&buffer_start)
		{
			while (*p)
			{
				if (*p != ' ' && *p != '\t') break;
				++p;
			}
			buffer_start = p;

			int status = 0;
			char c;
			while (1)
			{
				switch (status)
				{
				case 0:
					c = *p++;
					if (isdigit(c)) status = 1;
					else if (isalpha(c) || '_' == c) status = 4;
					else
					{
						switch (c)
						{
						case '+':
							return TOK_OP_PLUS;
						case '-':
							return TOK_OP_MINUS;
						case '*':
							return TOK_OP_TIMES;
						case '/':
							return TOK_OP_DIVIDE;
						case '(':
							return TOK_PUNC_LPAREN;
						case ')':
							return TOK_PUNC_RPAREN;
						case ';':
							return TOK_PUNC_SEMI;
						case '=':
							return TOK_OP_ASSIGN;
						default:
							return TOK_ERROR;
						}
					}
					break;
				case 1:
					c = *p++;
					if ('.' == c) status = 2;
					else if (isdigit(c)) status = 1;
					else
					{
						p--;
						return TOK_CONST_INT;
					}
					break;
				case 2:
					c = *p++;
					if (isdigit(c)) status = 3;
					else return TOK_ERROR;
					break;
				case 3:
					c = *p++;
					if (isdigit(c)) status = 3;
					else
					{
						p--;
						return TOK_CONST_REAL;
					}
					break;
				case 4:
					c = *p++;
					if (isalpha(c) || '_' == c || isdigit(c)) status = 4;
					else
					{
						p--;
						return TOK_ID;
					}
					break;
				default:
					exit(-1);
					break;
				}
			}
		}


		int exec(const char *psrc)
		{
			char *p = (char*)psrc;
			char buffer[30];
			char *buffer_start;
			TokenType tok_type;
			TokenStruct token;

			while (*p)
			{
				tok_type = get_one_token(p, buffer_start);

				int idx = 0;
				while (buffer_start != p) buffer[idx++] = *buffer_start++;
				buffer[idx] = '\0';

				token.type = tok_type;
				token.col = (int)((p - psrc) / sizeof(char)) + 1;
				token.row = row;

				switch (tok_type)
				{
				case TOK_OP_ASSIGN:
				case TOK_OP_PLUS:
				case TOK_OP_MINUS:
				case TOK_OP_TIMES:
				case TOK_OP_DIVIDE:
				case TOK_PUNC_LPAREN:
				case TOK_PUNC_RPAREN:
				case TOK_PUNC_SEMI:
					TokenList.push_back(token);
					break;
				case TOK_CONST_INT:
					token.i_value = atoi(buffer);
					TokenList.push_back(token);
					break;
				case TOK_CONST_REAL:
					token.d_value = atof(buffer);
					TokenList.push_back(token);
					break;
				case TOK_ID:
					// msvc++ function strcpy_s
					strcpy_s(token.id_value, buffer);
					TokenList.push_back(token);
					break;
				case TOK_ERROR:
					ErrorList.push_back({ row,token.col,"lexcical error" });
					break;
				default:
					break;
				}
			}
			return 0;
		}

	};

}

#endif // DEMO_COMPLILER_SCANNER_HPP
