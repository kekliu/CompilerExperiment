#ifndef DEMO_COMPLILER_PARSER_HPP
#define DEMO_COMPLILER_PARSER_HPP

// ReSharper disable CppUseAuto
#include <iostream>
#include <list>
#include <stack>
#include "symbol.hpp"

using namespace std;


extern cmplr::SymbolTable symbol_table;

namespace cmplr
{

	double getvalue(TokenStruct &token)
	{
		if (token.type == TOK_CONST_INT)
			return token.i_value;
		if (token.type == TOK_CONST_REAL)
			return token.d_value;
		if (token.type == TOK_ID)
		{
			TokenStruct *t = symbol_table.getLToken(token.id_value);
			if (t)
				return getvalue(*t);
			else
			{
				char errorBuffer[256];
				sprintf_s(errorBuffer, "undefined identifier '%s'", token.id_value);
				throw exception(errorBuffer);
			}
		}
		return 0;
	}

	TokenStruct operator +(TokenStruct &l, TokenStruct &r)
	{
		double re = getvalue(l) + getvalue(r);
		if (l.type == TOK_CONST_INT&&r.type == TOK_CONST_INT)
			return TokenStruct(TOK_CONST_INT, int(re));
		return TokenStruct(TOK_CONST_REAL, re);
	}

	TokenStruct operator -(TokenStruct &l, TokenStruct &r)
	{
		double re = getvalue(l) - getvalue(r);
		if (l.type == TOK_CONST_INT&&r.type == TOK_CONST_INT)
			return TokenStruct(TOK_CONST_INT, int(re));
		return TokenStruct(TOK_CONST_REAL, re);
	}

	TokenStruct operator *(TokenStruct &l, TokenStruct &r)
	{
		double re = getvalue(l) * getvalue(r);
		if (l.type == TOK_CONST_INT&&r.type == TOK_CONST_INT)
			return TokenStruct(TOK_CONST_INT, int(re));
		return TokenStruct(TOK_CONST_REAL, re);
	}

	TokenStruct operator /(TokenStruct &l, TokenStruct &r)
	{
		double re = getvalue(l) / getvalue(r);
		if (l.type == TOK_CONST_INT&&r.type == TOK_CONST_INT)
			return TokenStruct(TOK_CONST_INT, int(re));
		return TokenStruct(TOK_CONST_REAL, re);
	}


	class parser
	{

		// public variables
		list<TokenStruct> &TokenList;
		list<ErrorMsg> &ErrorList;
		//list<Symbol> &SymbolList;
		SymbolTable &symtab;
		int &row;

		// assit variables
		list<TokenStruct> PostfixTokenlist;
		list<TokenStruct>::iterator it;
		char errorBuffer[256];

		// constructor
	public:
		parser(list<TokenStruct> &tlst, list<ErrorMsg> &elst, SymbolTable &slst, int r) :
			TokenList(tlst), ErrorList(elst), symtab(slst), row(r) { }



		AstNode *E()
		{
			AstNode *l = T();
			while (it->type == TOK_OP_PLUS || it->type == TOK_OP_MINUS)
			{
				TokenStruct token = *it;
				++it;
				AstNode *r_ast_node = T();
				l = new AstNode({ token,l,r_ast_node });
			}
			return l;
		}

		AstNode *T()
		{
			AstNode *l = F();
			while (it->type == TOK_OP_DIVIDE || it->type == TOK_OP_TIMES)
			{
				TokenStruct token = *it;
				++it;
				AstNode *r_ast_node = F();
				l = new AstNode({ token,l,r_ast_node });
			}
			return l;
		}

		AstNode *F()
		{
			AstNode *node = new AstNode({ *it,nullptr,nullptr });
			switch (it->type)
			{
			case TOK_CONST_INT:
			case TOK_CONST_REAL:
			case TOK_ID:
				++it;
				if (it->type == TOK_PUNC_LPAREN)
				{
					node = new AstNode({ node->tok,nullptr,nullptr });
					++it;
					node->tok.type = TOK_FUNC;
					node->left = E();
					if (it->type == TOK_PUNC_RPAREN)
						++it;
					else
						throw exception("expected ')'");
				}
				return node;
			case TOK_PUNC_LPAREN:
				++it;
				node = E();
				if (it->type == TOK_PUNC_RPAREN)
					++it;
				else
					throw exception("expected ')'");
				return node;
			default:
				delete node;
				sprintf_s(errorBuffer, "unexpected '%s'\n", TokenNames[it->type]);
				throw exception(errorBuffer);
			}
		}

		/**
		 * \brief S -> id=E; | id(E);
		 * \return
		 */
		AstNode *S()
		{
			if (it->type == TOK_ID)
			{
				AstNode *node = nullptr;
				TokenStruct token = *it;
				++it;
				if (it->type == TOK_OP_ASSIGN)
				{
					node = new AstNode({ *it,nullptr,nullptr });
					node->left = new AstNode({ token,nullptr,nullptr });
					++it;
					node->right = E();
				}
				else if (it->type == TOK_PUNC_LPAREN)
				{
					--it;
					node = E();
				}

				if (it->type == TOK_PUNC_SEMI && node)
					return node;
				else
				{
					cout << "expected ';'" << endl;
					return node;
					//throw exception("expected ';'");
				}
			}
			throw exception("invalid expression");
		}

		void PostTraverse(AstNode *tree)
		{
			if (tree)
			{
				PostTraverse(tree->left);
				PostTraverse(tree->right);
				//cout << "post-traverse: " << tree->tok << endl;
				PostfixTokenlist.push_back(tree->tok);
			}
		}

		void DestroyTree(AstNode *&tree)
		{
			if (tree)
			{
				DestroyTree(tree->left);
				DestroyTree(tree->right);
				delete tree;
				tree = nullptr;
			}
		}

		void calc(AstNode *tree) {
			PostTraverse(tree);
			stack<TokenStruct> TokenStack;
			TokenStruct r, l;
			double(*func)(double);

			//cout << PostfixTokenlist;

			for (list<TokenStruct>::iterator it = PostfixTokenlist.begin(); it != PostfixTokenlist.end(); ++it) {

				switch (it->type)
				{
				case TOK_CONST_INT:case TOK_CONST_REAL:case TOK_ID:
					TokenStack.push(*it);
					break;
				case TOK_OP_ASSIGN:
					r = TokenStack.top();
					TokenStack.pop();
					l = TokenStack.top();
					TokenStack.pop();
					{
						TokenStruct *ptok;
						if (r.type == TOK_ID)
							ptok = symbol_table.getLToken(r.id_value);
						else
							ptok = &r;
						if (ptok)
						{
							symbol_table.addOrUpdate(l.id_value, *ptok);
							TokenStack.push(*symbol_table.getLToken(l.id_value));
						}
						else
						{
							char errorBuffer[256];
							sprintf_s(errorBuffer, "undefined identifier '%s'", r.id_value);
							throw exception(errorBuffer);
						}
					}
					break;
				case TOK_OP_PLUS:case TOK_OP_MINUS:case TOK_OP_TIMES:case TOK_OP_DIVIDE:
					r = TokenStack.top();
					TokenStack.pop();
					l = TokenStack.top();
					TokenStack.pop();
					if (it->type == TOK_OP_PLUS)
						TokenStack.push(l + r);
					else if (it->type == TOK_OP_MINUS)
						TokenStack.push(l - r);
					else if (it->type == TOK_OP_TIMES)
						TokenStack.push(l * r);
					else
					{
						if (getvalue(r) == 0)
							throw exception("divided by zero");
						TokenStack.push(l / r);
					}
					break;
				case TOK_FUNC:
					r = TokenStack.top();
					TokenStack.pop();
					func = getFunction(it->id_value);
					if (func)
						TokenStack.push({ TOK_CONST_REAL,func(getvalue(r)) });
					else
					{
						sprintf_s(errorBuffer, "undefined function '%s'", static_cast<char*>(it->id_value));
						throw exception("function not found");
					}
					break;
				default:
					sprintf_s(errorBuffer, "%s is not a valid ast node", TokenNames[it->type]);
					throw exception(errorBuffer);
				}

			}

			//cout << "size of stack: " << TokenStack.size() << "  result: " << TokenStack.top().d_value << endl;

		}

	public:
		int exec()
		{
			// add an EOF token to the end of the token list to make the recursion terminated normally
			TokenList.push_back({ TOK_EOF });

			it = TokenList.begin();

			//cout << "syntax analyzer:" << endl;

			AstNode *tree = S();

			calc(tree);

			if (it->type == TOK_PUNC_SEMI || it->type == TOK_EOF)
			{
				//cout << "right expr!!!" << endl;
			}
			else
			{
				//cout << "error at row " << it->row << ",column " << it->col << ": ";
				cout << "unexpected '" << TokenNames[it->type] << "'" << endl;
			}

			DestroyTree(tree);
			return 0;
		}

	};

}

#endif
